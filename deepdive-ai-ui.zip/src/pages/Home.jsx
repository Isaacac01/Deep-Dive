import ChatUI from "../components/ChatUI";
import AgentPanel from "../components/AgentPanel";

export default function Home() {
  return (
    <div className="layout">
      <AgentPanel />
      <ChatUI />
    </div>
  );
}