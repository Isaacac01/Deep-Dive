import { useState } from "react";

export default function InputBox({ onSend }) {
  const [val, setVal] = useState("");

  return (
    <div className="input">
      <input value={val} onChange={(e) => setVal(e.target.value)} />
      <button onClick={() => { onSend(val); setVal(""); }}>
        Send
      </button>
    </div>
  );
}