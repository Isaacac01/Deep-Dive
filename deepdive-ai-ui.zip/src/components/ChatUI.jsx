import { useState } from "react";
import InputBox from "./InputBox";
import Message from "./Message";

export default function ChatUI() {
  const [messages, setMessages] = useState([
    { role: "ai", text: "DeepDive online. Multi-agent system ready." }
  ]);

  const send = (text) => {
    setMessages([
      ...messages,
      { role: "user", text },
      { role: "ai", text: "🧠 Agents processing request..." }
    ]);
  };

  return (
    <div className="chat">
      <div className="messages">
        {messages.map((m, i) => (
          <Message key={i} role={m.role} text={m.text} />
        ))}
      </div>
      <InputBox onSend={send} />
    </div>
  );
}