export default function AgentPanel() {
  const agents = ["Planner", "Research", "Coder", "Memory"];

  return (
    <div className="panel">
      <h3>Agents</h3>
      {agents.map((a, i) => (
        <div key={i} className="agent">{a}</div>
      ))}
    </div>
  );
}