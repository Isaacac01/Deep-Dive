export default function SplashScreen() {
  return (
    <div className="splash">
      <div className="orb"></div>
      <h1>DeepDive AI</h1>
      <p>Initializing Multi-Agent System...</p>
    </div>
  );
}