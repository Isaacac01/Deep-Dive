import chromadb

class ChromaStore:
    def __init__(self, path='./memory_db'):
        self.client = chromadb.PersistentClient(path=path)
        self.collection = self.client.get_or_create_collection('deepdive')

    def add(self, text):
        self.collection.add(documents=[text], ids=[str(hash(text))])

    def search(self, query):
        return self.collection.query(query_texts=[query], n_results=5)
