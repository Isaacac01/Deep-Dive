class Planner:
    def create_plan(self, task):
        return {'steps': [{'id': 1, 'task': task}]}
