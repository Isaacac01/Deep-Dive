class AgentRouter:
    def route(self, task):
        text = task.lower()
        if 'code' in text:
            return 'coding'
        return 'research'
