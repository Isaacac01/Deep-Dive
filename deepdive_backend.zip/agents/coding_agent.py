from agents.base_agent import BaseAgent

class CodingAgent(BaseAgent):
    def __init__(self):
        super().__init__('coding')

    def execute(self, task, context):
        return {'agent': self.name, 'result': f'Code: {task}'}
