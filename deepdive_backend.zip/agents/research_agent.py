from agents.base_agent import BaseAgent

class ResearchAgent(BaseAgent):
    def __init__(self):
        super().__init__('research')

    def execute(self, task, context):
        return {'agent': self.name, 'result': f'Research: {task}'}
