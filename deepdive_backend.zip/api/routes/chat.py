from fastapi import APIRouter
from orchestrator.orchestrator import Orchestrator

router = APIRouter()
orchestrator = Orchestrator()

@router.post('/chat')
async def chat(payload: dict):
    task = payload['message']
    result = orchestrator.run(task)
    return {'response': result}
