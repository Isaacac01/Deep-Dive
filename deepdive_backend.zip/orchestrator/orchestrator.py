from planner.planner import Planner
from planner.router import AgentRouter
from agents.research_agent import ResearchAgent
from agents.coding_agent import CodingAgent

class Orchestrator:
    def __init__(self):
        self.planner = Planner()
        self.router = AgentRouter()
        self.agents = {
            'research': ResearchAgent(),
            'coding': CodingAgent()
        }

    def run(self, task):
        plan = self.planner.create_plan(task)
        results = []
        for step in plan['steps']:
            route = self.router.route(step['task'])
            result = self.agents[route].execute(step['task'], {})
            results.append(result)
        return results
